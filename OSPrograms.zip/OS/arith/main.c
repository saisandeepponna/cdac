#include <stdio.h>
#include "arith.h"

int main(int argc, char const *argv[])
{
    printf("Add: %d\n", add(10,20));
    printf("Sub: %d\n", sub(10,20));
    printf("Mul: %d\n", mul(10,20));
    return 0;
}